package com.example.imagegallery

import android.content.Context
import androidx.room.*

@Entity
data class Image(
    @PrimaryKey val filename: String,
    @ColumnInfo(name = "description") val description: String?,
    @ColumnInfo(name = "sum_ratings") val sumRatings: Int = 0,
    @ColumnInfo(name = "no_ratings") val noRatings: Int = 0
)

@Dao
interface ImageDao {
    @Query("SELECT filename FROM image")
    fun getFilename(): List<String>

    @Query("SELECT sum_ratings FROM image WHERE filename = :filename")
    fun getRatings(filename: String): Int

    @Query("SELECT no_ratings FROM image WHERE filename = :filename")
    fun getNoRatings(filename: String): Int

    @Query("SELECT description FROM image WHERE filename = :filename")
    fun getDescription(filename: String): String

    @Insert
    fun insertAll(vararg images: Image)
}

@Database(entities = arrayOf(Image::class), version = 1)
abstract class GalleryDatabase : RoomDatabase() {
    abstract fun userDao(): ImageDao

    companion object {

        @Volatile private var INSTANCE: GalleryDatabase? = null

        fun getInstance(context: Context): GalleryDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }

        private fun buildDatabase(context: Context) =
            Room.databaseBuilder(context.applicationContext,
                GalleryDatabase::class.java, "images.db")
                .build()
    }
}
