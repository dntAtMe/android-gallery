package com.example.imagegallery

import android.content.Context
import android.util.Log
import java.io.File

class StorageManager {

    companion object {
        fun createFile(context: Context?) {
            val filename = "myfile"
            val fileContents = "1,10,4"
            context?.openFileOutput(filename, Context.MODE_PRIVATE).use {
                it?.write(fileContents.toByteArray())
            }

        }

        fun writeFile(context: Context?, filename: String, contents: String) {

        }

        fun openFile(context: Context?, filename: String) {
            val path = context?.filesDir?.path + "/" + filename
            var file = File(path)

            Log.d("READIN", file.readLines().toString())
        }
    }

}