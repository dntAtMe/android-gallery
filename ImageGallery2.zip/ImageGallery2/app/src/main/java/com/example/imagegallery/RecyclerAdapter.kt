package com.example.imagegallery

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup


public class RecyclerAdapter(val list: ArrayList<String>) : RecyclerView.Adapter<ImageViewHolder>() {

    private var selectedPos = RecyclerView.NO_POSITION

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ImageViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ImageViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(viewHolder: ImageViewHolder, i: Int) {
        viewHolder.setText()
    }




}
