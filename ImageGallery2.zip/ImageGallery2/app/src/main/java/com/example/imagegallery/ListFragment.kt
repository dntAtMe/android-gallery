package com.example.imagegallery

import android .content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentTransaction
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.image_list.*

public class ListFragment : Fragment() {
    private var dualPane: Boolean = false

    private lateinit var viewManager: RecyclerView.LayoutManager
    private var curCheckPosition = 0

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        curCheckPosition = savedInstanceState?.getInt("curChoice", 0) ?: 0
        val detailsFrame: View? = activity?.findViewById(R.id.details)
        dualPane = detailsFrame?.visibility == View.VISIBLE
        Log.d("DUAL", dualPane.toString())
        if (dualPane) {
            showDetails(curCheckPosition)
        }
        StorageManager.createFile(context)

    }

    fun showDetails(position: Int) {
        curCheckPosition = position

        if (dualPane) {
            // We can display everything in-place with fragments, so update
            // the list to highlight the selected item and show the data.

            // Check what fragment is currently shown, replace if needed.
            //var details = fragmentManager?.findFragmentById(R.id.details) as? DetailFragment

            //if (details.shownIndex != position) {
                // Make new fragment to show this selection.
                var details = DetailFragment.newInstance(position)

                // Execute a transaction, replacing any existing fragment
                // with this one inside the frame.
                fragmentManager?.beginTransaction()?.apply {
                    if (position == 0) {
                        this.add(R.id.details, details);
                    } else {
                        this.replace(R.id.details, details);
                    }
                    setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                    commit()
               // }
            }

        } else {
            // Otherwise we need to launch a new activity to display
            // the dialog fragment with selected text.
            val intent = Intent().apply {
                setClass(activity, DetailActivity::class.java)
                putExtra("index", position)
            }
            startActivity(intent)
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view: View = inflater.inflate(R.layout.image_list, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var list: ArrayList<String>  = arrayListOf("1", "2", "3", "4", "5", "6", "7", "8", "1", "2", "3", "4", "5", "6", "7", "8")
        viewManager = GridLayoutManager(activity, 2)
        recycler_view.layoutManager = viewManager
        recycler_view.adapter = RecyclerAdapter(list)
        recycler_view.addOnItemTouchListener(
            RecyclerItemClickListener(view.context, recycler_view, object : RecyclerItemClickListener.OnItemClickListener {
                override fun onItemClick(view: View, position: Int) {
                    Log.d("ABCD ", position.toString())
                    showDetails(position)
                }

                override fun onLongItemClick(view: View?, position: Int) {
                    // do whatever
                }
            })
        )
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("curChoice", curCheckPosition)

    }
}